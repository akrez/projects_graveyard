## The main files of the project

[app/Console/Commands/GenerateLoanScheduleCommand.php](https://github.com/akrez/lendo/blob/main/app/Console/Commands/GenerateLoanScheduleCommand.php) 

[app/Dto/Dto.php](https://github.com/akrez/lendo/blob/main/app/Dto/Dto.php) 

[app/Dto/Loan/GenerateLoanScheduleDto.php](https://github.com/akrez/lendo/blob/main/app/Dto/Loan/GenerateLoanScheduleDto.php) 

[app/Facades/Loan/GenerateLoanScheduleFacade.php](https://github.com/akrez/lendo/blob/main/app/Facades/Loan/GenerateLoanScheduleFacade.php) 

[app/Providers/AppServiceProvider.php](https://github.com/akrez/lendo/blob/main/app/Providers/AppServiceProvider.php) 

[app/Services/Loan/GenerateLoanScheduleService.php](https://github.com/akrez/lendo/blob/main/app/Services/Loan/GenerateLoanScheduleService.php) 

[app/Support/ApiResponse.php](https://github.com/akrez/lendo/blob/main/app/Support/ApiResponse.php) 

[config/loan.php](https://github.com/akrez/lendo/blob/main/config/loan.php) 

[tests/Feature/Loan/GenerateLoanScheduleTest.php](https://github.com/akrez/lendo/blob/main/tests/Feature/Loan/GenerateLoanScheduleTest.php) 

[tests/Unit/Loan/GenerateLoanScheduleTest.php](https://github.com/akrez/lendo/blob/main/tests/Unit/Loan/GenerateLoanScheduleTest.php) 

## An example of successful execution

```shell
php artisan loan:generate-schedule --amount=50000000 --term=12 --annual_rate=0.12 --start_date=2025-01-01
```

<img src="./ok.png">

## An example of an error

```shell
php artisan loan:generate-schedule --amount=0 --term=-1 --annual_rate=string --start_date=2025
```

<img src="./error.png">