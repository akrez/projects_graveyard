<?php

namespace App\Providers;

use App\Services\Loan\GenerateLoanScheduleService;
use App\Support\ApiResponse;
use Illuminate\Support\Facades\App;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        App::bind(ApiResponse::class, function () {
            return new ApiResponse;
        });
        //
        App::bind(GenerateLoanScheduleService::class, function () {
            return new GenerateLoanScheduleService;
        });
    }
}
