<?php

namespace App\Dto\Loan;

use App\Dto\Dto;
use Illuminate\Support\Carbon;

/**
 * @property null|int $amount
 * @property null|int $term
 * @property null|float $annual_rate
 * @property null|string $start_date
 */
class GenerateLoanScheduleDto extends Dto
{
    public function __construct(
        public $amount,
        public $term,
        public $annual_rate,
        public $start_date
    ) {}

    public function rules($context)
    {
        return [
            'amount' => ['required', 'int', 'gt:0'],
            'term' => ['required', 'int', 'gt:0'],
            'annual_rate' => ['required', 'numeric', 'gt:0'],
            'start_date' => ['required', 'date_format:Y-m-d'],
        ];
    }

    public function startDate(): ?Carbon
    {
        return $this->start_date ? Carbon::parse($this->start_date) : null;
    }
}
