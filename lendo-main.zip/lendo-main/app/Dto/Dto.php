<?php

namespace App\Dto;

use Illuminate\Support\Facades\Validator;
use ReflectionClass;

abstract class Dto
{
    abstract public function rules($context);

    public function data()
    {
        $result = [];
        //
        foreach (static::getConstructorParameters() as $parameter) {
            $parameterName = $parameter->getName();
            $result[$parameterName] = $this->$parameterName;
        }

        return $result;
    }

    public function messages()
    {
        return [];
    }

    public function attributes()
    {
        return [];
    }

    public function validate($context = null)
    {
        return Validator::make(
            $this->data(),
            $this->rules($context),
            $this->messages(),
            $this->attributes()
        );
    }

    public static function fromArray($array): static
    {
        return new static(...$array);
    }

    protected static function getConstructorParameters(): array
    {
        return (new ReflectionClass(static::class))
            ->getConstructor()
            ->getParameters();
    }
}
