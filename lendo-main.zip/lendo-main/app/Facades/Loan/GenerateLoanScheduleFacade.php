<?php

namespace App\Facades\Loan;

use App\Services\Loan\GenerateLoanScheduleService;
use Illuminate\Support\Facades\Facade;

class GenerateLoanScheduleFacade extends Facade
{
    /**
     * Get the registered name of the component.
     *
     * @return string
     */
    protected static function getFacadeAccessor()
    {
        return GenerateLoanScheduleService::class;
    }
}
