<?php

namespace App\Console\Commands;

use App\Dto\Loan\GenerateLoanScheduleDto;
use App\Facades\Loan\GenerateLoanScheduleFacade;
use Illuminate\Console\Command;

class GenerateLoanScheduleCommand extends Command
{
    protected $signature = 'loan:generate-schedule {--amount=} {--term=} {--annual_rate=} {--start_date=}';

    protected $description = 'Generate a fixed installment loan repayment schedule';

    public function handle()
    {
        $dto = GenerateLoanScheduleDto::fromArray([
            'amount' => $this->option('amount'),
            'term' => $this->option('term'),
            'annual_rate' => $this->option('annual_rate'),
            'start_date' => $this->option('start_date'),
        ]);

        $errors = collect($dto->validate()->errors()->toArray());
        if ($errors->isNotEmpty()) {
            $this->components->error(422);
            foreach ($errors as $field => $messages) {
                foreach ($messages as $message) {
                    $this->components->warn("{$field}: {$message}");
                }
            }

            return Command::FAILURE;
        }

        $result = GenerateLoanScheduleFacade::handle($dto);
        if (! $result->isSuccessful()) {
            $this->components->error($result->getStatus());

            return Command::FAILURE;
        }

        $this->components->success($result->getStatus());
        $data = $result->getData();
        $this->table(array_keys(reset($data)), $data);

        return Command::SUCCESS;

    }
}
