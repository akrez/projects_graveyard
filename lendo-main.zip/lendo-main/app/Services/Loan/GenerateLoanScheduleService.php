<?php

namespace App\Services\Loan;

use App\Dto\Loan\GenerateLoanScheduleDto;
use App\Support\ApiResponse;

class GenerateLoanScheduleService
{
    public function __invoke(GenerateLoanScheduleDto $generateLoanScheduleDto): ApiResponse
    {
        return $this->handle($generateLoanScheduleDto);
    }

    public function handle(GenerateLoanScheduleDto $generateLoanScheduleDto): ApiResponse
    {
        try {
            $precision = $this->getPrecision();

            $monthlyRate = ($generateLoanScheduleDto->annual_rate / 12) / 100;

            $pmt = $this->calcPmt($generateLoanScheduleDto->amount, $monthlyRate, $generateLoanScheduleDto->term, $precision);

            $remainAmount = $generateLoanScheduleDto->amount;

            $totalInterest = 0;

            $schedules = [];
            for ($installment = 1; $installment <= $generateLoanScheduleDto->term; $installment++) {

                $interest = round($remainAmount * $monthlyRate, $precision);
                $principal = round($pmt - $interest, $precision);

                $remainAmount -= $principal;
                $totalInterest += $interest;

                $schedules[] = [
                    'installment' => $installment,
                    'payment_date' => $generateLoanScheduleDto->startDate()->copy()->addMonthsNoOverflow($installment - 1)->toDateString(),
                    'total_payment' => $pmt,
                    'principal' => $principal,
                    'interest' => $interest,
                    'total_interest' => $totalInterest,
                ];
            }

            return app(ApiResponse::class)->status(200)->data($schedules);
        } catch (\Exception $e) {
            return app(ApiResponse::class)->status(500)->message($e->getMessage());
        }
    }

    public function calcPmt(int $amount, float $monthlyRate, int $term, int $precision): float
    {
        $pmt = $amount * $monthlyRate * pow(1 + $monthlyRate, $term) / (pow(1 + $monthlyRate, $term) - 1);

        return round($pmt, $precision);
    }

    protected function getPrecision(): int
    {
        return config('loan.precision');
    }
}
