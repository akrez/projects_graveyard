<?php

return [
    'precision' => env('LOAN_PRECISION', 0),
];
