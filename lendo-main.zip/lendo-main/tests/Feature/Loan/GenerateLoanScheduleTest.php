<?php

namespace Tests\Feature\Loan;

use Illuminate\Console\Command;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class GenerateLoanScheduleTest extends TestCase
{
    // use RefreshDatabase;

    public function test_it_generates_schedule_with_valid_input()
    {
        $this->artisan('loan:generate-schedule', [
            '--amount' => 50_000_000,
            '--term' => 12,
            '--annual_rate' => 0.01,
            '--start_date' => '2025-01-01',
        ])
            ->assertExitCode(Command::SUCCESS);
    }

    public function test_it_requires_amount()
    {
        $this->artisan('loan:generate-schedule')
            ->expectsOutputToContain('amount: The amount field is required')
            ->expectsOutputToContain('term: The term field is required')
            ->expectsOutputToContain('annual_rate: The annual rate field is required')
            ->expectsOutputToContain('start_date: The start date field is required')
            ->assertExitCode(Command::FAILURE);
    }

    public function test_it_rejects_string_start_date_format()
    {
        $this->artisan('loan:generate-schedule', [
            '--amount' => 50_000_000,
            '--term' => 12,
            '--annual_rate' => 0.01,
            '--start_date' => 'note-aa-da',
        ])
            ->expectsOutputToContain('start_date: The start date field must match the format Y-m-d')
            ->assertExitCode(Command::FAILURE);
    }

    public function test_it_rejects_invalid_start_date_format()
    {
        $this->artisan('loan:generate-schedule', [
            '--amount' => 50_000_000,
            '--term' => 12,
            '--annual_rate' => 0.01,
            '--start_date' => '2025-1-1',
        ])
            ->expectsOutputToContain('start_date: The start date field must match the format Y-m-d')
            ->assertExitCode(Command::FAILURE);
    }

    public function test_it_rejects_non_numeric_amount()
    {
        $this->artisan('loan:generate-schedule', [
            '--amount' => 'fifty-million',
            '--term' => 12,
            '--annual_rate' => 0.01,
            '--start_date' => '2025-01-01',
        ])
            ->expectsOutputToContain('amount: The amount field must be an integer.')
            ->assertExitCode(Command::FAILURE);
    }

    public function test_it_rejects_zero_amount()
    {
        $this->artisan('loan:generate-schedule', [
            '--amount' => 0,
            '--term' => 12,
            '--annual_rate' => 0.01,
            '--start_date' => '2025-01-01',
        ])
            ->expectsOutputToContain('amount: The amount field must be greater than 0')
            ->assertExitCode(Command::FAILURE);
    }

    public function test_it_rejects_zero_term()
    {
        $this->artisan('loan:generate-schedule', [
            '--amount' => 50_000_000,
            '--term' => 0,
            '--annual_rate' => 0.01,
            '--start_date' => '2025-01-01',
        ])
            ->expectsOutputToContain('term: The term field must be greater than 0')
            ->assertExitCode(Command::FAILURE);
    }

    public function test_it_rejects_negative_annual_rate()
    {
        $this->artisan('loan:generate-schedule', [
            '--amount' => 50_000_000,
            '--term' => 0,
            '--annual_rate' => -1,
            '--start_date' => '2025-01-01',
        ])
            ->expectsOutputToContain('annual_rate: The annual rate field must be greater than 0')
            ->assertExitCode(Command::FAILURE);
    }

    public function test_it_rejects_string_annual_rate()
    {
        $this->artisan('loan:generate-schedule', [
            '--amount' => 50_000_000,
            '--term' => 0,
            '--annual_rate' => 'annual_rate',
            '--start_date' => '2025-01-01',
        ])
            ->expectsOutputToContain('annual_rate: The annual rate field must be a number')
            ->assertExitCode(Command::FAILURE);
    }

    public function test_it_accepts_minimum_valid_values()
    {
        $this->artisan('loan:generate-schedule', [
            '--amount' => 1,
            '--term' => 1,
            '--annual_rate' => 0.01,
            '--start_date' => '2025-01-01',
        ])
            ->assertExitCode(Command::SUCCESS);
    }

    public function test_it_rejects_command_with_non_numeric_annual_rate()
    {
        $this->artisan('loan:generate-schedule', [
            '--amount' => 10000,
            '--term' => 12,
            '--annual_rate' => 'five percent',
            '--start_date' => '2025-01-01',
        ])
            ->assertExitCode(1);
    }
}
