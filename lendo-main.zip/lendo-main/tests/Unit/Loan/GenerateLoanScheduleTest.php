<?php

namespace Tests\Unit\Loan;

use App\Services\Loan\GenerateLoanScheduleService;
use PHPUnit\Framework\TestCase;

class GenerateLoanScheduleTest extends TestCase
{
    private GenerateLoanScheduleService $service;

    protected function setUp(): void
    {
        parent::setUp();
        $this->service = new GenerateLoanScheduleService;
    }

    public function test_it_calculates_correct_payment_for_basic_loan()
    {
        $amount = 50_000_000;
        $monthlyRate = 0.01;
        $term = 12;
        $precision = 0;

        $result = $this->service->calcPmt($amount, $monthlyRate, $term, $precision);

        $this->assertEquals(4442439, $result);
    }

    public function test_it_returns_correct_precision()
    {
        $amount = 50_000_000;
        $monthlyRate = 0.01;
        $term = 12;
        $precision = 4;

        $result = $this->service->calcPmt($amount, $monthlyRate, $term, $precision);

        $this->assertEquals(4442439.4339, $result);
    }

    public function test_it_throw_error_on_zero_interest_loan()
    {
        $this->expectException(\DivisionByZeroError::class);

        $amount = 10000;
        $monthlyRate = 0;
        $term = 10;
        $precision = 0;

        $this->service->calcPmt($amount, $monthlyRate, $term, $precision);
    }

    public function test_it_throw_error_on_zero_term_loan()
    {
        $this->expectException(\DivisionByZeroError::class);

        $amount = 1000;
        $monthlyRate = 1;
        $term = 0;
        $precision = 0;

        $this->service->calcPmt($amount, $monthlyRate, $term, $precision);
    }
}
