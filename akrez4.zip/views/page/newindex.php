<?php

use app\models\Page;
use dosamigos\ckeditor\CKEditor;
use yii\helpers\Html;
use yii\helpers\Url;
use yii\widgets\ActiveForm;
use froala\froalaeditor\FroalaEditorWidget;
use kartik\editors\Summernote;

$this->title = Yii::t('app', 'Page')  . ' ' . Yii::t('app', $model->entity) . ': ' .  ($entityModel ? $entityModel->title : Yii::t('app', $model->entity_id));
?>

<h1><?= Html::encode($this->title) ?></h1>

<?php $form = ActiveForm::begin(); ?>
<div class="row">
    <div class="col-sm-12">
        <?php

        echo $form->field($model, 'body')->widget(CKEditor::class, [
            'model' => $model,
            'attribute' => 'body',
            'preset' => 'standard',
            'clientOptions' => [
                'language' => 'fa',
                'contentsLangDirection' => 'rtl',
            ],
        ]);

        // echo FroalaEditorWidget::widget([
        //     'model' => $model,
        //     'attribute' => 'body',
        //     'options' => [
        //         // html attributes
        //         'id' => 'content',
        //     ],
        //     'clientOptions' => [
        //         'theme' => 'royal', //optional: dark, red, gray, royal
        //         'language' => 'fa', // optional: ar, bs, cs, da, de, en_ca, en_gb, en_us ...
        //         'direction' => 'rtl',
        //     ]
        // ]);

        // echo Summernote::widget([
        //     'model' => $model,
        //     'attribute' => 'body',
        //     'useKrajeePresets' => true,
        //     'pluginOptions' => [
        //         'height' => 300,
        //         'dialogsFade' => true,
        //         'toolbar' => [
        //             ['style1', ['style']],
        //             ['style2', ['bold', 'italic', 'underline', 'strikethrough', 'superscript', 'subscript']],
        //             ['font', [ 'fontsize', 'color', 'clear']],
        //             ['para', ['ul', 'ol', 'paragraph', 'height']],
        //             ['insert', ['link', 'picture', 'video', 'table', 'hr']],
        //         ],
        //         'fontSizes' => ['8', '9', '10', '11', '12', '13', '14', '16', '18', '20', '24', '36', '48'],
        //         'codemirror' => [
        //             'lineNumbers' => true,
        //             'styleActiveLine' => true,
        //             'matchBrackets' => true,
        //             'smartIndent' => true,
        //         ],
        //     ]
        // ]);

        // echo $form->field($model, 'body')->widget(Summernote::class, [
        //     // 'useKrajeePresets' => true,
        //     // other widget settings
        // ]);

        ?>
    </div>
</div>
<div class="row">
    <div class="col-sm-3">
        <?= $form->field($model, 'status')->dropDownList(Page::validStatuses())->label(false) ?>
    </div>
</div>
<div class="row">
    <div class="col-sm-3">
        <?= Html::submitButton($model->isNewRecord ? ' <span class="glyphicon glyphicon-plus"></span> ' . Yii::t('app', 'Create') : ' <span class="glyphicon glyphicon-pencil"></span> ' . Yii::t('app', 'Update'), ['class' => 'btn btn-block btn-social ' . ($model->isNewRecord ? 'btn-success' : 'btn-primary')]); ?>
    </div>
    <div class="col-sm-6">
    </div>
    <div class="col-sm-3">
        <?php
        $url = null;
        if ($entityModel && $model->entity == Page::ENTITY_CATEGORY) {
            $url = Url::to([0 => 'category/index']);
        } else if ($entityModel && $model->entity == Page::ENTITY_PRODUCT) {
            $url = Url::to([0 => 'product/index', 'parent_id' => $entityModel->category_id]);
        }
        if ($url) {
            echo Html::a(' <span class="glyphicon glyphicon-share-alt"></span> ' . Yii::t('app', 'Back'), $url, ['class' => 'btn btn-default btn-block btn-social']);
        }
        ?>
    </div>
</div>

<?php ActiveForm::end(); ?>